// SPDX-License-Identifier: MIT
pragma solidity ^0.8.20;

import "@openzeppelin/contracts/token/ERC20/IERC20.sol";
import "@openzeppelin/contracts/access/Ownable.sol";

/**
 * @title SubmissionVault
 * @notice Circular backing vault for Persistent Solutions.
 *         Hunters pay a submission fee in PCENT/JRTS.
 *         Fees are locked here — this balance IS the backing.
 *         Transparent to anyone who checks the contract.
 * 
 *         Terms: hunter consents before submitting. Fee is non-refundable.
 *         The scope is clear. The rules are visible.
 *         This is not a trap. It's a game everyone agrees to play.
 */
contract SubmissionVault is Ownable {
    IERC20 public feeToken;
    string public tokenSymbol;
    uint256 public feeAmount;
    uint256 public totalFeesCollected;
    uint256 public totalSubmissions;

    event FeePaid(address indexed hunter, uint256 amount, uint256 submissionId);
    event FeeWithdrawn(address indexed to, uint256 amount);
    event FeeAmountUpdated(uint256 oldFee, uint256 newFee);

    constructor(address _feeToken, string memory _symbol, uint256 _feeAmount) Ownable(msg.sender) {
        feeToken = IERC20(_feeToken);
        tokenSymbol = _symbol;
        feeAmount = _feeAmount;
    }

    /**
     * @notice Hunter pays submission fee.
     *         Consent given via signed terms before this call.
     */
    function payFee(uint256 submissionId) external returns (bool) {
        require(feeToken.transferFrom(msg.sender, address(this), feeAmount), "Transfer failed");
        totalFeesCollected += feeAmount;
        totalSubmissions++;
        emit FeePaid(msg.sender, feeAmount, submissionId);
        return true;
    }

    /**
     * @notice Current backing = tokens held by this vault.
     */
    function backingBalance() external view returns (uint256) {
        return feeToken.balanceOf(address(this));
    }

    /**
     * @notice Owner withdraws fees for operations.
     *         Visible on-chain. Transparent.
     */
    function withdraw(uint256 amount, address to) external onlyOwner {
        require(feeToken.transfer(to, amount), "Withdraw failed");
        emit FeeWithdrawn(to, amount);
    }

    /**
     * @notice Update fee. Old fee grandfathered for existing terms.
     */
    function setFeeAmount(uint256 _feeAmount) external onlyOwner {
        uint256 old = feeAmount;
        feeAmount = _feeAmount;
        emit FeeAmountUpdated(old, _feeAmount);
    }
}
