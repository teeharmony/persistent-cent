// SPDX-License-Identifier: MIT
pragma solidity ^0.8.20;

import "@openzeppelin/contracts/token/ERC20/IERC20.sol";
import "@openzeppelin/contracts/access/Ownable.sol";
import "@openzeppelin/contracts/utils/ReentrancyGuard.sol";

/**
 * @title PCENTStaking
 * @notice Staking contract for PersistentCent token.
 *         Stakers earn yield from platform fees and unlock premium access.
 *         "Bandwidth" = total value staked + platform activity (tx volume).
 */
contract PCENTStaking is Ownable, ReentrancyGuard {
    IERC20 public pcent;

    // ---------- Staking ----------
    struct Stake {
        uint256 amount;
        uint256 timestamp;
        uint256 lastRewardClaim;
        uint8 tier; // 0=base, 1=premium, 2=elite
    }

    mapping(address => Stake) public stakes;
    uint256 public totalStaked;
    uint256 public rewardRate; // tokens per second per total staked (scaled 1e18)
    uint256 public constant MIN_STAKE = 1_000_000 * 10**18; // 1M PCENT min
    uint256 public constant UNSTAKE_COOLDOWN = 7 days;

    // ---------- Fees / Revenue ----------
    uint256 public platformRevenue; // total PCENT collected as fees
    uint256 public revenueDistributed;
    uint256 public feePercent = 5; // 5% fee on bounties paid in PCENT

    // ---------- Bandwidth Tracking ----------
    struct BandwidthRecord {
        uint256 totalStaked;
        uint256 platformRevenue;
        uint256 activeResearchers;
        uint256 bountiesPaid;
        uint256 timestamp;
    }

    BandwidthRecord[] public bandwidthHistory;
    uint256 public activeResearchers;
    uint256 public totalBountiesPaid;

    // ---------- Events ----------
    event Staked(address indexed user, uint256 amount, uint8 tier);
    event Unstaked(address indexed user, uint256 amount);
    event RewardClaimed(address indexed user, uint256 amount);
    event FeeCollected(address indexed from, uint256 amount, string program);
    event BandwidthUpdated(uint256 totalStaked, uint256 revenue, uint256 researchers);

    constructor(address _pcent) Ownable(msg.sender) {
        require(_pcent != address(0), "Invalid PCENT address");
        pcent = IERC20(_pcent);
        rewardRate = 365 * 10**14; // ~3.65% APY (scaled)
    }

    // ---------- Modifiers ----------
    modifier hasMinStake() {
        require(stakes[msg.sender].amount >= MIN_STAKE, "Below min stake");
        _;
    }

    // ---------- Staking ----------
    function stake(uint256 amount) external nonReentrant {
        require(amount > 0, "Amount must be > 0");
        require(pcent.transferFrom(msg.sender, address(this), amount), "Transfer failed");

        Stake storage s = stakes[msg.sender];
        if (s.amount == 0) activeResearchers++;

        s.amount += amount;
        s.timestamp = block.timestamp;
        s.lastRewardClaim = block.timestamp;

        // Determine tier
        if (s.amount >= 100_000_000 * 10**18) s.tier = 2; // 100M PCENT = Elite
        else if (s.amount >= 10_000_000 * 10**18) s.tier = 1; // 10M = Premium
        else s.tier = 0; // Base

        totalStaked += amount;
        _recordBandwidth();

        emit Staked(msg.sender, amount, s.tier);
    }

    function unstake(uint256 amount) external nonReentrant {
        Stake storage s = stakes[msg.sender];
        require(s.amount >= amount, "Insufficient stake");
        require(block.timestamp >= s.timestamp + UNSTAKE_COOLDOWN, "Cooldown active");

        // Claim pending rewards first
        _claimReward(msg.sender);

        s.amount -= amount;
        totalStaked -= amount;
        require(pcent.transfer(msg.sender, amount), "Transfer failed");

        if (s.amount == 0) {
            activeResearchers--;
            s.tier = 0;
        }

        _recordBandwidth();
        emit Unstaked(msg.sender, amount);
    }

    // ---------- Rewards ----------
    function claimReward() external nonReentrant {
        _claimReward(msg.sender);
    }

    function _claimReward(address user) internal {
        Stake storage s = stakes[user];
        if (s.amount == 0) return;

        uint256 elapsed = block.timestamp - s.lastRewardClaim;
        uint256 reward = (s.amount * rewardRate * elapsed) / 1e18;

        // Cap reward to available balance
        uint256 available = pcent.balanceOf(address(this)) - totalStaked;
        if (reward > available) reward = available;

        if (reward > 0) {
            s.lastRewardClaim = block.timestamp;
            require(pcent.transfer(user, reward), "Reward transfer failed");
            emit RewardClaimed(user, reward);
        } else {
            s.lastRewardClaim = block.timestamp;
        }
    }

    // ---------- Fee Collection ----------
    function collectFee(address from, uint256 amount, string calldata program) external onlyOwner {
        require(pcent.transferFrom(from, address(this), amount), "Fee transfer failed");
        platformRevenue += amount;
        totalBountiesPaid++;
        _recordBandwidth();
        emit FeeCollected(from, amount, program);
    }

    // ---------- Bandwidth ----------
    function _recordBandwidth() internal {
        bandwidthHistory.push(BandwidthRecord({
            totalStaked: totalStaked,
            platformRevenue: platformRevenue,
            activeResearchers: activeResearchers,
            bountiesPaid: totalBountiesPaid,
            timestamp: block.timestamp
        }));

        // Keep last 1000 records
        if (bandwidthHistory.length > 1000) {
            for (uint i = 0; i < 999; i++) {
                bandwidthHistory[i] = bandwidthHistory[i + 1];
            }
            bandwidthHistory.pop();
        }

        emit BandwidthUpdated(totalStaked, platformRevenue, activeResearchers);
    }

    // ---------- Views ----------
    function getStakerInfo(address user) external view returns (
        uint256 amount, uint8 tier, uint256 pendingReward, uint256 cooldownEnd
    ) {
        Stake storage s = stakes[user];
        amount = s.amount;
        tier = s.tier;
        uint256 elapsed = block.timestamp - s.lastRewardClaim;
        pendingReward = (s.amount * rewardRate * elapsed) / 1e18;
        cooldownEnd = s.timestamp + UNSTAKE_COOLDOWN;
    }

    function getBandwidth() external view returns (
        uint256 staked, uint256 revenue, uint256 researchers, uint256 bounties
    ) {
        return (totalStaked, platformRevenue, activeResearchers, totalBountiesPaid);
    }

    function getBandwidthHistory(uint256 count) external view returns (BandwidthRecord[] memory) {
        uint256 len = bandwidthHistory.length;
        uint256 take = count < len ? count : len;
        BandwidthRecord[] memory result = new BandwidthRecord[](take);
        for (uint i = 0; i < take; i++) {
            result[i] = bandwidthHistory[len - take + i];
        }
        return result;
    }

    // ---------- Admin ----------
    function setRewardRate(uint256 _rate) external onlyOwner {
        rewardRate = _rate;
    }

    function setFeePercent(uint256 _pct) external onlyOwner {
        require(_pct <= 20, "Max 20%");
        feePercent = _pct;
    }

    function withdrawAccidentalTokens(address token, uint256 amount) external onlyOwner {
        require(token != address(pcent), "Cannot withdraw PCENT");
        IERC20(token).transfer(owner(), amount);
    }
}
