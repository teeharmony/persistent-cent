const hre = require("hardhat");

async function main() {
  const [deployer] = await hre.ethers.getSigners();
  console.log("Deploying with account:", deployer.address);

  const presaleStart = Math.floor(Date.now() / 1000) + 3600;
  const presaleEnd = presaleStart + 14 * 24 * 3600;
  const presaleRate = 100000;
  const minPurchase = hre.ethers.parseEther("0.01");
  const maxPurchase = hre.ethers.parseEther("10");
  const softCap = hre.ethers.parseEther("50");
  const hardCap = hre.ethers.parseEther("500");

  const PersistentCent = await hre.ethers.getContractFactory("PersistentCent");
  const token = await PersistentCent.deploy(
    deployer.address, presaleStart, presaleEnd, presaleRate,
    minPurchase, maxPurchase, softCap, hardCap
  );
  await token.waitForDeployment();
  const tokenAddress = await token.getAddress();
  console.log("PersistentCent deployed to:", tokenAddress);

  // Transfer 500M PCENT to deployer for staking rewards
  const rewardAmount = hre.ethers.parseEther("500000000");
  const tx = await token.transfer(deployer.address, rewardAmount);
  await tx.wait();
  console.log("Transferred 500M PCENT to deployer for rewards");

  // Now deploy staking contract
  const PCENTStaking = await hre.ethers.getContractFactory("PCENTStaking");
  const staking = await PCENTStaking.deploy(tokenAddress);
  await staking.waitForDeployment();
  const stakingAddress = await staking.getAddress();
  console.log("PCENTStaking deployed to:", stakingAddress);

  // Fund staking contract with reward tokens
  const fundTx = await token.transfer(stakingAddress, rewardAmount);
  await fundTx.wait();
  console.log("Funded staking contract with 500M PCENT for rewards");

  // Verify
  const stakingBal = await token.balanceOf(stakingAddress);
  console.log("\n=== Deployment Complete ===");
  console.log("PCENT:     ", tokenAddress);
  console.log("Staking:   ", stakingAddress);
  console.log("Rewards:   ", hre.ethers.formatEther(stakingBal), "PCENT");
  console.log("Min stake: ", hre.ethers.formatEther(await staking.MIN_STAKE()), "PCENT");
  console.log("APY:       ~3.65%");
}

main().then(() => process.exit(0)).catch(e => { console.error(e); process.exit(1); });
